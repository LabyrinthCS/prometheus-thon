#ifndef BREAD_H
#define BREAD_H

/* include HAL layer */
#include "hal.h"

/* include drivers */
#include "Led_1.h"
#include "button_1.h"

bool bread_init();

#endif /* BREAD_H */