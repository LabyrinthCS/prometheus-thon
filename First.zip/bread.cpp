#include "bread.h"

bool bread_init() {
    uart_start(9600);
    bool failed = false;
    // [{'alias': u'Led_1', 'type': <autogen.breadware.hardware_module_mapper.DataSensor object at 0x7fa2747c7190>, 'file': 'led_ws2812', 'map': {'pin': '69', 'PIN': '69'}}, {'alias': u'button_1', 'type': <autogen.breadware.hardware_module_mapper.DataSensor object at 0x7fa2747c7d90>, 'file': 'button', 'map': {'PIN': '67', 'pin': '67'}}]
    if (!Led_1.init()) {
      uart_print_char_array("\n\nFAILed to initialise Led_1\n\n");
      failed = true;
    }
    if (!button_1.init()) {
      uart_print_char_array("\n\nFAILed to initialise button_1\n\n");
      failed = true;
    }

    return !failed;
      
}
