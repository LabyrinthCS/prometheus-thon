#ifndef Led_1_H
#define Led_1_H

/*
 * Header File for Driver:
 *
 * Alias: "Led_1" 
 * Type: "led_ws2812"
 *
 * Generated from C source file with Python
 *
 * Built with BREAD
 */

#include "hal.h"

struct Led_1_namespace {
    bool (*init)();
    void (*setRGB)(uint8_t, uint8_t, uint8_t);
    void (*off)();
};

extern struct Led_1_namespace const Led_1;

#endif /* Led_1_H */
