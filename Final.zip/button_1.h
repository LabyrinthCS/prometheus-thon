#ifndef button_1_H
#define button_1_H

/*
 * Header File for Driver:
 *
 * Alias: "button_1" 
 * Type: "button"
 *
 * Generated from C source file with Python
 *
 * Built with BREAD
 */

#include "hal.h"

struct button_1_namespace {
    bool (*init)();
    uint16_t (*is_pressed)();
};

extern struct button_1_namespace const button_1;

#endif /* button_1_H */
