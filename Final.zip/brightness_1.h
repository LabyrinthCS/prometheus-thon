#ifndef brightness_1_H
#define brightness_1_H

/*
 * Header File for Driver:
 *
 * Alias: "brightness_1" 
 * Type: "bright_tsl2561"
 *
 * Generated from C source file with Python
 *
 * Built with BREAD
 */

#include "hal.h"

struct brightness_1_namespace {
    bool (*init)();
    float (*read)();
};

extern struct brightness_1_namespace const brightness_1;

#endif /* brightness_1_H */
