#ifndef knob_1_H
#define knob_1_H

/*
 * Header File for Driver:
 *
 * Alias: "knob_1" 
 * Type: "knob"
 *
 * Generated from C source file with Python
 *
 * Built with BREAD
 */

#include "hal.h"

struct knob_1_namespace {
    bool (*init)();
    uint16_t (*read)();
};

extern struct knob_1_namespace const knob_1;

#endif /* knob_1_H */
