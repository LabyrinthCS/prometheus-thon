#ifndef acc_1_H
#define acc_1_H

/*
 * Header File for Driver:
 *
 * Alias: "acc_1" 
 * Type: "accel_mma8652"
 *
 * Generated from C source file with Python
 *
 * Built with BREAD
 */

#include "hal.h"

struct acc_1_namespace {
    bool (*init)();
    float (*read_x)();
    float (*read_y)();
    float (*read_z)();
};

extern struct acc_1_namespace const acc_1;

#endif /* acc_1_H */
