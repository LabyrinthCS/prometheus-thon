#ifndef BREAD_CONSTANTS_H
#define BREAD_CONSTANTS_H
/*
 * Global project constants to be includes where needed
 */

String PROJECT_ID = "fd971c7c-9b1d-448f-b797-278e298468af";
String USERNAME = "minimini";
String DEVICE_ID = "";
String DEVICE_NAME = "abcd";
String PROCESSOR_TYPE = "MEGA";

#endif
