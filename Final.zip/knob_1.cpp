/*
 * C Source File for Driver:
 *
 * Alias: "knob_1" 
 * Type: "knob"
 *
 * Generated from C source file with Python
 *
 * Built with BREAD
 */

#include "knob_1.h"

/* Required Values */ 
uint8_t const pin = 65;

bool knob_1_init()
{
  return true;
}

/**
 * Return the position of the knob, expressed
 * as a percentage of the full range of motion.
 * 0 corresponds to the anti-clockwise extremum.
 * 100 corresponds to the clocwise extremum.
 */
uint16_t knob_1_read()
{
  return (gpio_analog_read(pin) / 1023.0) * 100;
}

/* Define external alias */
struct knob_1_namespace const knob_1 = {
    knob_1_init,
    knob_1_read
};
