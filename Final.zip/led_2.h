#ifndef led_2_H
#define led_2_H

/*
 * Header File for Driver:
 *
 * Alias: "led_2" 
 * Type: "led_ws2812"
 *
 * Generated from C source file with Python
 *
 * Built with BREAD
 */

#include "hal.h"

struct led_2_namespace {
    bool (*init)();
    void (*setRGB)(uint8_t, uint8_t, uint8_t);
    void (*off)();
};

extern struct led_2_namespace const led_2;

#endif /* led_2_H */
