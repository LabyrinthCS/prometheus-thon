/*
 * C Source File for Driver:
 *
 * Alias: "speaker_1" 
 * Type: "speaker"
 *
 * Generated from C source file with Python
 *
 * Built with BREAD
 */

#include "speaker_1.h"

/* Required Values */ 
uint8_t const PIN = 12;

bool speaker_1_init()
{
  gpio_set_output(PIN);
  return true;
}

/**
 * Output a tone at a desired frequency.
 *
 * @param frequency_hz the frequency of the desired output tone. Range: 20Hz to 20000Hz. Use 0 for off.
 */
void speaker_1_write(int frequency_hz)
{
  if (frequency_hz == 0) {
    gpio_pwm(PIN, 100, 1);
  } else {
    gpio_pwm(PIN, frequency_hz, 0);
  }
}

/* Define external alias */
struct speaker_1_namespace const speaker_1 = {
    speaker_1_init,
    speaker_1_write
};
