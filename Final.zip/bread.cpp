#include "bread.h"

bool bread_init() {
    uart_start(9600);
    bool failed = false;
    // [{'alias': u'Led_1', 'type': <autogen.breadware.hardware_module_mapper.DataSensor object at 0x7fa274a8a150>, 'file': 'led_ws2812', 'map': {'pin': '69', 'PIN': '69'}}, {'alias': u'button_1', 'type': <autogen.breadware.hardware_module_mapper.DataSensor object at 0x7fa274a8ae90>, 'file': 'button', 'map': {'PIN': '67', 'pin': '67'}}, {'alias': u'brightness_1', 'type': <autogen.breadware.hardware_module_mapper.DataSensor object at 0x7fa2746c86d0>, 'file': 'bright_tsl2561', 'map': {}}, {'alias': u'speaker_1', 'type': <autogen.breadware.hardware_module_mapper.DataSensor object at 0x7fa2746c8990>, 'file': 'speaker', 'map': {'PIN': '12', 'pin': '12'}}, {'alias': u'mic_1', 'type': <autogen.breadware.hardware_module_mapper.DataSensor object at 0x7fa2746c8690>, 'file': 'mic_max4466', 'map': {'PIN': '63', 'pin': '63'}}, {'alias': u'knob_1', 'type': <autogen.breadware.hardware_module_mapper.DataSensor object at 0x7fa2746c8190>, 'file': 'knob', 'map': {'PIN': '65', 'pin': '65'}}, {'alias': u'led_2', 'type': <autogen.breadware.hardware_module_mapper.DataSensor object at 0x7fa2746c8590>, 'file': 'led_ws2812', 'map': {'pin': '66', 'PIN': '66'}}, {'alias': u'acc_1', 'type': <autogen.breadware.hardware_module_mapper.DataSensor object at 0x7fa2746c84d0>, 'file': 'accel_mma8652', 'map': {}}]
    if (!Led_1.init()) {
      uart_print_char_array("\n\nFAILed to initialise Led_1\n\n");
      failed = true;
    }
    if (!button_1.init()) {
      uart_print_char_array("\n\nFAILed to initialise button_1\n\n");
      failed = true;
    }
    if (!brightness_1.init()) {
      uart_print_char_array("\n\nFAILed to initialise brightness_1\n\n");
      failed = true;
    }
    if (!speaker_1.init()) {
      uart_print_char_array("\n\nFAILed to initialise speaker_1\n\n");
      failed = true;
    }
    if (!mic_1.init()) {
      uart_print_char_array("\n\nFAILed to initialise mic_1\n\n");
      failed = true;
    }
    if (!knob_1.init()) {
      uart_print_char_array("\n\nFAILed to initialise knob_1\n\n");
      failed = true;
    }
    if (!led_2.init()) {
      uart_print_char_array("\n\nFAILed to initialise led_2\n\n");
      failed = true;
    }
    if (!acc_1.init()) {
      uart_print_char_array("\n\nFAILed to initialise acc_1\n\n");
      failed = true;
    }

    return !failed;
      
}
