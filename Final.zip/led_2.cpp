/*
 * C Source File for Driver:
 *
 * Alias: "led_2" 
 * Type: "led_ws2812"
 *
 * Generated from C source file with Python
 *
 * Built with BREAD
 */

#include "led_2.h"

/* Required Values */ 
int8_t const PIN = 66;

#include <stdlib.h>
#include <string.h>

#ifdef __AVR__
#include "Arduino.h"
#endif

uint8_t *led_2_pixels;
uint32_t led_2_endTime;

volatile uint8_t *led_2_port;
uint8_t led_2_pinMask;
uint8_t led_2_currentRed = 0;
uint8_t led_2_currentGreen = 0;
uint8_t led_2_currentBlue = 0;

inline bool led_2_canShow(void) {
  return (get_micros() - led_2_endTime) >= 300L;
}

bool led_2_init()
{
  if((led_2_pixels = (uint8_t *)malloc(3))) {
    memset(led_2_pixels, 0, 3);
  }
  gpio_write(PIN, false);

  volatile uint8_t *our_port;
  uint8_t our_pinMask;

#ifdef __AVR__
  our_port = portOutputRegister(digitalPinToPort(PIN));
  our_pinMask = digitalPinToBitMask(PIN);
#endif
  led_2_port = our_port;
  led_2_pinMask = our_pinMask;

  return true;
}

 /**
  * Turns on the LED to a certain color using a RGB color model.
  *
  * @param red Intensity of the color RED as an integer between 0 and 255.
  * @param green Intensity of the color GREEN as an integer between 0 and 255.
  * @param blue Intensity of the color BLUE as an integer between 0 and 255.
  */
void led_2_setRGB(uint8_t red, uint8_t green, uint8_t blue) {
  if (led_2_currentRed == red &&
      led_2_currentGreen == green &&
      led_2_currentBlue == blue) {
    return;
  } else {
    led_2_currentRed = red;
    led_2_currentGreen = green;
    led_2_currentBlue = blue;
  }

uint8_t
  wOffset = (((1 << 6) | (1 << 4) | (0 << 2) | (2))>> 6) & 0b11,
  rOffset = (((1 << 6) | (1 << 4) | (0 << 2) | (2))>> 4) & 0b11,
  gOffset = (((1 << 6) | (1 << 4) | (0 << 2) | (2))>> 2) & 0b11,
  bOffset =  ((1 << 6) | (1 << 4) | (0 << 2) | (2))      & 0b11;

  uint8_t *p;
  p = &led_2_pixels[0];

  p[rOffset] = red;
  p[gOffset] = green;
  p[bOffset] = blue;

  if(!led_2_pixels) {
    return;
  }

  while(!led_2_canShow());

  volatile uint16_t
    i   = 3;
  volatile uint8_t
   *ptr = led_2_pixels,
    b   = *ptr++,
    hi,
    lo;

    volatile uint8_t next, bit;

    hi   = *led_2_port |  led_2_pinMask;
    lo   = *led_2_port & ~led_2_pinMask;
    next = lo;
    bit  = 8;

    volatile uint8_t *our_port = led_2_port;

    #ifdef __AVR__
    asm volatile(
     "head66:"                   "\n\t"
      "st   %a[port_num],  %[hi]"    "\n\t"
      "sbrc %[byte],  7"         "\n\t"
       "mov  %[next], %[hi]"     "\n\t"
      "dec  %[bit]"              "\n\t"
      "st   %a[port_num],  %[next]"  "\n\t"
      "mov  %[next] ,  %[lo]"    "\n\t"
      "breq nextbyte66"          "\n\t"
      "rol  %[byte]"             "\n\t"
      "rjmp .+0"                 "\n\t"
      "nop"                      "\n\t"
      "st   %a[port_num],  %[lo]"    "\n\t"
      "nop"                      "\n\t"
      "rjmp .+0"                 "\n\t"
      "rjmp head66"              "\n\t"
     "nextbyte66:"               "\n\t"
      "ldi  %[bit]  ,  8"        "\n\t"
      "ld   %[byte] ,  %a[ptr]+" "\n\t"
      "st   %a[port_num], %[lo]"     "\n\t"
      "nop"                      "\n\t"
      "sbiw %[count], 1"         "\n\t"
       "brne head66"             "\n"
      : [port_num]  "+e" (our_port),
        [byte]  "+r" (b),
        [bit]   "+r" (bit),
        [next]  "+r" (next),
        [count] "+w" (i)
      : [ptr]    "e" (ptr),
        [hi]     "r" (hi),
        [lo]     "r" (lo)
);
#endif

  led_2_endTime = get_micros();
}

/**
 * Turns off the LED.
 */
void led_2_off() {
  led_2_setRGB(0, 0, 0);
}

/* Define external alias */
struct led_2_namespace const led_2 = {
    led_2_init,
    led_2_setRGB,
    led_2_off
};
