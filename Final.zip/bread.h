#ifndef BREAD_H
#define BREAD_H

/* include HAL layer */
#include "hal.h"

/* include drivers */
#include "Led_1.h"
#include "button_1.h"
#include "brightness_1.h"
#include "speaker_1.h"
#include "mic_1.h"
#include "knob_1.h"
#include "led_2.h"
#include "acc_1.h"

bool bread_init();

#endif /* BREAD_H */