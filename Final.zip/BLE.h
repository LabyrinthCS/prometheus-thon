#include "Arduino.h"

String bluetoothModuleSetup(String);
