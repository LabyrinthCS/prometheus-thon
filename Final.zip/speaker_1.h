#ifndef speaker_1_H
#define speaker_1_H

/*
 * Header File for Driver:
 *
 * Alias: "speaker_1" 
 * Type: "speaker"
 *
 * Generated from C source file with Python
 *
 * Built with BREAD
 */

#include "hal.h"

struct speaker_1_namespace {
    bool (*init)();
    void (*write)(int);
};

extern struct speaker_1_namespace const speaker_1;

#endif /* speaker_1_H */
