#ifndef mic_1_H
#define mic_1_H

/*
 * Header File for Driver:
 *
 * Alias: "mic_1" 
 * Type: "mic_max4466"
 *
 * Generated from C source file with Python
 *
 * Built with BREAD
 */

#include "hal.h"

struct mic_1_namespace {
    bool (*init)();
    uint16_t (*read)();
};

extern struct mic_1_namespace const mic_1;

#endif /* mic_1_H */
